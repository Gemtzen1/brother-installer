#!/bin/bash

sudo zypper install dcpl2600dpdrv-4.1.0-1.i386.rpm brscan5-1.3.5-0.i386.rpm brscan-skey-0.3.2-0.i386.rpm brother-udev-rule-type1-1.0.2-0.noarch.rpm


